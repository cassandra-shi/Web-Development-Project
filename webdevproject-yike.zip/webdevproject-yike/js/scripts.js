// Show the slideshow and play automatically
document.addEventListener('DOMContentLoaded', function() {
    new Splide('.splide', {
      type: 'slide',
      perPage: 1,
      autoplay: true,
      pauseOnHover: false,
    }).mount();
  });

  // Show the Lightbox and dimmer
setTimeout(function() {
    $('#dimmer').fadeIn();
    $('#lightbox').fadeIn();
  });
  
  // Hide the Lightbox and dimmer when the user clicks outside of it
  $(document).on('click', function(event) {
    if ($(event.target).is('#lightbox') || $(event.target).parents('#lightbox').length) {
      return;
    }
    $('#lightbox').fadeOut();
    $('#dimmer').fadeOut();
  });
  


